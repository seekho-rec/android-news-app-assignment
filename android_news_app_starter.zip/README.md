# Android News App Assignment

This is the starter project for the Android Developer assessment.